/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fashion.designing.system;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * @author ADMIN
 */
public class AssignmentForm extends javax.swing.JFrame {

    /**
     * Creates new form AssignmentForm
     */
    public AssignmentForm() {
        initComponents();
        
        qty.setText("1");
        setID();
        setDate();
        saveButton.setVisible(false);
         
         comboRetrieve();
         //itemRetrieve();
        
        
        
    }
    //***************************************************
    //Clear Data ************************************//**
     public void clearDate(){                        //**
     if(selectProduct.getSelectedIndex()>0){         //**
                                                     //**
     selectProduct.setSelectedItem("Select item");   //**
     }                                               //**
     else if(selectStaff.getSelectedIndex()>0){      //**
                                                     //**
     selectStaff.setSelectedItem("Select Staff");    //**
     }                                               //**
      qty.setText("1");                              //**
      txt1.setText("");                              //**
      txt2.setText("");                              //**
     }                                               //**
    //***********************************************//**
    //***************************************************
    
    //Retrieving rates from database according to item selection
    public void setRate(){
       DBconnection db=new DBconnection();
       String s1=(String) selectProduct.getSelectedItem();
       switch(s1){
           case "Shirt":  
                        try{
                            Statement stmt = db.conn.createStatement();
                            ResultSet rs = stmt.executeQuery("select staff_rate,cust_rate from rates where item_name='"+s1+"' ");
                            while(rs.next()){
                            int i1=rs.getShort("staff_rate");
                            int i2=rs.getShort("cust_rate");
                            
                             
                           
                            String getStaffRate=String.valueOf(i1);                            
                            String getCusRate=String.valueOf(i2);
                            
                            txt1.setText(getStaffRate);
                            txt2.setText(getCusRate);
                            }
                           }catch(SQLException e){}  
            case "Pant":  try{
                            Statement stmt = db.conn.createStatement();
                            ResultSet rs = stmt.executeQuery("select staff_rate,cust_rate from rates where item_name='"+s1+"' ");
                             while(rs.next()){
                            int i1=rs.getShort("staff_rate");
                            int i2=rs.getShort("cust_rate");
                            
                             
                           
                            String getStaffRate=String.valueOf(i1);                            
                            String getCusRate=String.valueOf(i2);
                            
                            txt1.setText(getStaffRate);
                            txt2.setText(getCusRate);
                             }
                           }catch(SQLException e){}
             case "Sherwani":  try{
                            Statement stmt = db.conn.createStatement();
                            ResultSet rs = stmt.executeQuery("select staff_rate,cust_rate from rates where item_name='"+s1+"' ");
                             while(rs.next()){
                           int i1=rs.getShort("staff_rate");
                            int i2=rs.getShort("cust_rate");
                            
                             
                           
                            String getStaffRate=String.valueOf(i1);                            
                            String getCusRate=String.valueOf(i2);
                            
                            txt1.setText(getStaffRate);
                            txt2.setText(getCusRate);
                             }
                           }catch(SQLException e){}
              case "Pathani":  try{
                            Statement stmt = db.conn.createStatement();
                            ResultSet rs = stmt.executeQuery("select staff_rate,cust_rate from rates where item_name='"+s1+"' ");
                             while(rs.next()){
                            int i1=rs.getShort("staff_rate");
                            int i2=rs.getShort("cust_rate");
                            
                             
                           
                            String getStaffRate=String.valueOf(i1);                            
                            String getCusRate=String.valueOf(i2);
                            
                            txt1.setText(getStaffRate);
                            txt2.setText(getCusRate);
                             }
                           }catch(SQLException e){}
               case "Suit":  try{
                            Statement stmt = db.conn.createStatement();
                            ResultSet rs = stmt.executeQuery("select staff_rate,cust_rate from rates where item_name='"+s1+"' ");
                            
                            int c1=Integer.parseInt(qty.getText());  
                            
                            while(rs.next()){
                            int i1=rs.getShort("staff_rate");
                            int i2=rs.getShort("cust_rate");
                            
                             
                           
                            String getStaffRate=String.valueOf(i1);                            
                            String getCusRate=String.valueOf(i2);
                            
                            txt1.setText(getStaffRate);
                            txt2.setText(getCusRate);
//                            
                            }
                           }catch(SQLException e){}
               case "Safari":  try{
                            Statement stmt = db.conn.createStatement();
                            ResultSet rs = stmt.executeQuery("select staff_rate,cust_rate from rates where item_name='"+s1+"' ");
                             while(rs.next()){
//                            
                            int i1=rs.getShort("staff_rate");
                            int i2=rs.getShort("cust_rate");
                            
                             
                           
                            String getStaffRate=String.valueOf(i1);                            
                            String getCusRate=String.valueOf(i2);
                            
                            txt1.setText(getStaffRate);
                            txt2.setText(getCusRate);
                             }
                           }catch(SQLException e){}
 
             
                   }
       try{
        Statement stmt = db.conn.createStatement();
        ResultSet rs = stmt.executeQuery("select * from rates");
       }catch(SQLException e){
       
       }    
    }
    //Retrieving Item from database
     public void itemRetrieve()
    {
    DBconnection db=new DBconnection();
    try {
        Statement stmt = db.conn.createStatement();
        ResultSet rs = stmt.executeQuery("select * from rates");
        
        
          
        while (rs.next()) {
           String pat = rs.getString("item_name");
            selectProduct.addItem(pat);
            
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(null, e);
    }
    }
    //Retrieving staff name into combobox
    
    public void comboRetrieve()
    {
    DBconnection db=new DBconnection();
    try {
             Statement stmt = db.conn.createStatement();
                ResultSet rs = stmt.executeQuery("select * from staff");
                while (rs.next()) {
            String pat = rs.getString("staff_name");
            selectStaff.addItem(pat);
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(null, e);
    }
    }
    
//Generating or stting Customer id 
    public void setID() {
        AutoIncreament obj = new AutoIncreament();
        int putOrd;
        putOrd = obj.auto_increment();
        ID.setText("" + putOrd);
        ID.setHorizontalAlignment(JLabel.CENTER);
    }

    public void setDate() //setting Assignment  date
    {
        LocalDate dd = LocalDate.now();
        int y = dd.getYear();
        int d = dd.getDayOfMonth();
        int m = dd.getMonthValue();

        String myArray[] = new String[3];
        myArray[0] = "" + d;
        myArray[1] = "/" + m;
        myArray[2] = "/" + y;
        String value = "";
        for (int i = 0; i < myArray.length; i++) {

            value += myArray[i];
            System.out.println(value);
        }
        dt.setText(value);
        dt.setHorizontalAlignment(JLabel.CENTER);

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        ID = new javax.swing.JLabel();
        dt = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        selectStaff = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        deliveyDate = new org.jdesktop.swingx.JXDatePicker();
        jLabel4 = new javax.swing.JLabel();
        qty = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel6 = new javax.swing.JLabel();
        selectProduct = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        Status = new javax.swing.JTextField();
        addButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        CancelButton = new javax.swing.JButton();
        saveButton = new javax.swing.JButton();
        txt1 = new javax.swing.JTextField();
        txt2 = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);
        setResizable(false);
        setSize(new java.awt.Dimension(790, 320));
        setType(java.awt.Window.Type.POPUP);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 172, 37));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ID.setBackground(new java.awt.Color(255, 255, 255));
        ID.setBorder(new javax.swing.border.MatteBorder(null));
        ID.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        ID.setOpaque(true);
        jPanel1.add(ID, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 60, 30));

        dt.setBackground(new java.awt.Color(255, 255, 255));
        dt.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        dt.setOpaque(true);
        jPanel1.add(dt, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 20, 110, 30));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fashion/designing/system/image/delivery date  copy.png"))); // NOI18N
        jLabel2.setText("Delivery Date");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 20, 110, 30));

        selectStaff.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Staff" }));
        selectStaff.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                selectStaffItemStateChanged(evt);
            }
        });
        selectStaff.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                selectStaffMouseDragged(evt);
            }
        });
        selectStaff.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                selectStaffMouseClicked(evt);
            }
        });
        selectStaff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectStaffActionPerformed(evt);
            }
        });
        jPanel1.add(selectStaff, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 70, 130, 30));

        jLabel3.setText("Qty");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 80, 30, -1));

        deliveyDate.setToolTipText("Select date");
        deliveyDate.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                deliveyDateFocusGained(evt);
            }
        });
        deliveyDate.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                deliveyDateMouseEntered(evt);
            }
        });
        deliveyDate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deliveyDateActionPerformed(evt);
            }
        });
        jPanel1.add(deliveyDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 22, 130, 30));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fashion/designing/system/image/assignment date icon copy.png"))); // NOI18N
        jLabel4.setText("Assignment Date");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 20, -1, 30));

        qty.setText("1");
        qty.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                qtyMouseClicked(evt);
            }
        });
        qty.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                qtyInputMethodTextChanged(evt);
            }
        });
        qty.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                qtyActionPerformed(evt);
            }
        });
        qty.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                qtyKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                qtyKeyTyped(evt);
            }
        });
        jPanel1.add(qty, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 70, 50, 30));

        jLabel5.setText("Order ID:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 60, -1));

        jSeparator1.setBackground(new java.awt.Color(96, 203, 135));
        jSeparator1.setOpaque(true);
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 790, 60));

        jLabel6.setText("Assign to");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 70, 70, 30));

        selectProduct.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select item" }));
        selectProduct.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                selectProductFocusGained(evt);
            }
        });
        selectProduct.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                selectProductMouseClicked(evt);
            }
        });
        selectProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectProductActionPerformed(evt);
            }
        });
        jPanel1.add(selectProduct, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 130, 30));

        jLabel7.setText("Status");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 70, 50, 30));

        Status.setText("Under Proccess");
        Status.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StatusActionPerformed(evt);
            }
        });
        jPanel1.add(Status, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 70, 130, 30));

        addButton.setBackground(new java.awt.Color(255, 172, 37));
        addButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fashion/designing/system/plus.png"))); // NOI18N
        addButton.setToolTipText("");
        addButton.setBorder(null);
        addButton.setOpaque(false);
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });
        jPanel1.add(addButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 60, 50, 50));

        jTable1.setBackground(new java.awt.Color(255, 172, 37));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Item", "Quantity", "Staff", "Delivery Date"
            }
        ));
        jTable1.setGridColor(new java.awt.Color(255, 181, 110));
        jTable1.setSelectionBackground(new java.awt.Color(255, 172, 37));
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, 750, 140));

        CancelButton.setBackground(new java.awt.Color(255, 172, 37));
        CancelButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fashion/designing/system/image/CancelB.png"))); // NOI18N
        CancelButton.setText("Cancel");
        CancelButton.setOpaque(false);
        CancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelButtonActionPerformed(evt);
            }
        });
        jPanel1.add(CancelButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 270, 120, 30));

        saveButton.setBackground(new java.awt.Color(255, 172, 37));
        saveButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fashion/designing/system/image/save.png"))); // NOI18N
        saveButton.setText("Save");
        saveButton.setAlignmentY(0.0F);
        saveButton.setOpaque(false);
        saveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveButtonActionPerformed(evt);
            }
        });
        jPanel1.add(saveButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(277, 270, 110, 30));

        txt1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt1ActionPerformed(evt);
            }
        });
        jPanel1.add(txt1, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 270, 70, 30));
        jPanel1.add(txt2, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 270, 70, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 810, 320));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void selectStaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectStaffActionPerformed
       comboRetrieve();
    }//GEN-LAST:event_selectStaffActionPerformed

    private void deliveyDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deliveyDateActionPerformed
        saveButton.setVisible(true);
    }//GEN-LAST:event_deliveyDateActionPerformed

    private void selectProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectProductActionPerformed
   
        setRate();             
    }//GEN-LAST:event_selectProductActionPerformed

    private void CancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelButtonActionPerformed
        System.exit(0);
    }//GEN-LAST:event_CancelButtonActionPerformed

    private void saveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveButtonActionPerformed
            DBconnection db=new DBconnection();
            int n=selectProduct.getSelectedIndex();
            String s1=(String) selectStaff.getSelectedItem();
              String s4=(String) selectProduct.getSelectedItem();
            String s2="Select staff";
            String s3="Select staff";
      if (n==0){
       JOptionPane.showMessageDialog(null,"Select item!","Message",JOptionPane.INFORMATION_MESSAGE);
      }
            else if(s4.equals(s3)){
                
            JOptionPane.showMessageDialog(null,"Enter quantity","Message",JOptionPane.INFORMATION_MESSAGE);
            }
            else if(s1.equals(s2)){
                
            JOptionPane.showMessageDialog(null,"Select staff!","Message",JOptionPane.INFORMATION_MESSAGE);
            }
            else{   
           try{
                      Statement st=db.conn.createStatement();
                     String selected1 = (String) selectProduct.getSelectedItem();
                    System.out.println(selected1);
                     String selected2 = (String) selectStaff.getSelectedItem();
                    System.out.println(selected2);
                    SimpleDateFormat dateFormat=new SimpleDateFormat("mm/dd/yyyy");
                    String DeliveryDate=dateFormat.format(deliveyDate.getDate());

    
    System.out.println(DeliveryDate);
   
         
            int a=st.executeUpdate("insert into Assignment(assign_item,item_qty,assign_staff,assign_date,delivey_date,ordno,status,staff_rate,cust_rate)" +
                    "values ('"+selected1+"','"+qty.getText()+"','"+ selected2 +"','"+dt.getText()+"','"+DeliveryDate+"','"+ ID.getText() +"','"+Status.getText()+"','"+txt1.getText()+"','"+txt2.getText()+"')");
            if(a==1){ 
            JOptionPane.showMessageDialog(null,"Saved!","Message",JOptionPane.INFORMATION_MESSAGE);
            }
     
        } catch (SQLException ex) {
              
            Logger.getLogger(StaffInfo.class.getName()).log(Level.SEVERE, null, ex);
                
                
        }
            }
    }//GEN-LAST:event_saveButtonActionPerformed

    private void deliveyDateFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_deliveyDateFocusGained
       
    }//GEN-LAST:event_deliveyDateFocusGained

    private void deliveyDateMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deliveyDateMouseEntered
        
    }//GEN-LAST:event_deliveyDateMouseEntered

    private void selectStaffMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_selectStaffMouseClicked
           
     
    }//GEN-LAST:event_selectStaffMouseClicked

    private void selectStaffItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_selectStaffItemStateChanged
        
    }//GEN-LAST:event_selectStaffItemStateChanged

    private void selectStaffMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_selectStaffMouseDragged
        // TODO add your handling code here:
    }//GEN-LAST:event_selectStaffMouseDragged

    private void selectProductMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_selectProductMouseClicked
 itemRetrieve();   
    }//GEN-LAST:event_selectProductMouseClicked

    private void txt1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt1ActionPerformed

    private void qtyInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_qtyInputMethodTextChanged
                          
                       
       
                       
    }//GEN-LAST:event_qtyInputMethodTextChanged

    private void qtyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_qtyActionPerformed
        
        
    }//GEN-LAST:event_qtyActionPerformed

    private void qtyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_qtyKeyPressed
    
    }//GEN-LAST:event_qtyKeyPressed

    private void qtyKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_qtyKeyTyped
    
    }//GEN-LAST:event_qtyKeyTyped

    private void qtyMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_qtyMouseClicked
    
    }//GEN-LAST:event_qtyMouseClicked

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
            DBconnection db=new DBconnection();
            
            
            
            
            int n=selectProduct.getSelectedIndex();
            int m=selectStaff.getSelectedIndex();
            String s1=(String) selectStaff.getSelectedItem();
              String s4=(String) selectProduct.getSelectedItem();
            String s2="Select staff";
            String s3="Select item";
      if (n==0){
       JOptionPane.showMessageDialog(null,"Select item!","Message",JOptionPane.INFORMATION_MESSAGE);
      }
            else if(qty.getText().length()==0){
                
            JOptionPane.showMessageDialog(null,"Enter quantity","Message",JOptionPane.INFORMATION_MESSAGE);
            }
            else if(m==0){
                
            JOptionPane.showMessageDialog(null,"Select staff!","Message",JOptionPane.INFORMATION_MESSAGE);
            }
            else{   
           try{
            //***********************************************
            //Calculating amount*****************************
             int q=Integer.parseInt(qty.getText());      //** 
             int r1=Integer.parseInt(txt1.getText());    //**   
             int r2=Integer.parseInt(txt2.getText());    //**   
            String sRate=String.valueOf(q*r1);           //**
            String cRate=String.valueOf(q*r2);           //**
            //***********************************************
            //*********************************************** 
                     
               
               
                    Statement st=db.conn.createStatement();
                     String selected1 = (String) selectProduct.getSelectedItem();
                    System.out.println(selected1);
                     String selected2 = (String) selectStaff.getSelectedItem();
                    System.out.println(selected2);
                    SimpleDateFormat dateFormat=new SimpleDateFormat("mm/dd/yyyy");
                    String DeliveryDate=dateFormat.format(deliveyDate.getDate());

                        
                     System.out.println(DeliveryDate);
   
         
            int a=st.executeUpdate("insert into Assignment(assign_item,item_qty,assign_staff,assign_date,delivey_date,ordno,status,staff_rate,cust_rate)" +
                    "values ('"+selected1+"','"+qty.getText()+"','"+ selected2 +"','"+dt.getText()+"','"+DeliveryDate+"','"+ ID.getText() +"','"+Status.getText()+"','"+sRate+"','"+cRate+"')");
            if(a==1){ 
            JOptionPane.showMessageDialog(null,"Saved!","Message",JOptionPane.INFORMATION_MESSAGE);
                clearDate();
            }
     
        } catch (SQLException ex) {
              
            Logger.getLogger(StaffInfo.class.getName()).log(Level.SEVERE, null, ex);
                
                
        }
            }         
        
    }//GEN-LAST:event_addButtonActionPerformed

    private void selectProductFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_selectProductFocusGained
         itemRetrieve();
    }//GEN-LAST:event_selectProductFocusGained

    private void StatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StatusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_StatusActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AssignmentForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AssignmentForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AssignmentForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AssignmentForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AssignmentForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CancelButton;
    private javax.swing.JLabel ID;
    private javax.swing.JTextField Status;
    private javax.swing.JButton addButton;
    private org.jdesktop.swingx.JXDatePicker deliveyDate;
    private javax.swing.JLabel dt;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField qty;
    private javax.swing.JButton saveButton;
    private javax.swing.JComboBox<String> selectProduct;
    private javax.swing.JComboBox<String> selectStaff;
    private javax.swing.JTextField txt1;
    private javax.swing.JTextField txt2;
    // End of variables declaration//GEN-END:variables
}
