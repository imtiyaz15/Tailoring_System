/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fashion.designing.system;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 *
 * @author ADMIN
 */
public class DBconnection {
    Connection conn=null;
	DBconnection (){
		try{
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			conn=DriverManager.getConnection("jdbc:ucanaccess://D:\\BCA PROJECT\\SEM 6\\Fashion Designig mgmt Sys\\TheDB.accdb");
			if(conn!=null){
				System.out.println("Database is connected");
			}
		}catch(HeadlessException | ClassNotFoundException | SQLException e){
			System.out.println(e.getMessage());
			
		}
	}
	public Connection getConnection(){
		return conn;
		
	}
	public void destroy(){
		try{
			conn.close();
		}catch(SQLException ex){
			
		}
	}
    
    
}
