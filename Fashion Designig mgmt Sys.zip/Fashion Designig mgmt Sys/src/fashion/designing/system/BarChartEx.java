/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fashion.designing.system;

/**
 *
 * @author ADMIN
 */
import java.awt.*;
import javax.swing.*;
  


import java.awt.Color;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

public class BarChartEx extends JFrame {
    
    public BarChartEx() {
        
        initUI();
    }

    private void initUI() {

        CategoryDataset dataset = createDataset();

        JFreeChart chart = createChart(dataset);
        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        chartPanel.setBackground(Color.white);
        add(chartPanel);

        pack();
        setTitle("Bar chart");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private CategoryDataset createDataset() {
        
/////
int pay=0;
AddStaffPayment fordate=new AddStaffPayment();
      String dte= fordate.setDate();
        DBconnection db=new DBconnection(); 
   
    try{
     String q="select * from OrdrDeliveryCount where count_date='"+dte+"' ";
            //+ "where ord_date='"+dateCount.getText()+"' ";
   
        PreparedStatement pst = db.conn.prepareStatement(q);
       
        ResultSet rs = pst.executeQuery();
       
      String ordCount="";
    String delCount="";
    String ordCost="";
    String delCost="";
    int oCount=0;
    int oCost=0;
    int dCount=0;
    int dCost=0;
    while(rs.next()){
     ordCount=rs.getString("no_of_order");
     int a=Integer.parseInt(ordCount);
     oCount=oCount+a;
     ordCost=rs.getString("cost_of_order");
     int b =Integer.parseInt(ordCost);
     oCost=oCost+b;
     
     delCount=rs.getString("no_of_delivery");
     int c=Integer.parseInt(delCount);
     dCount=dCount+c;
     delCost=rs.getString("cost_of_delivery");
     int d=Integer.parseInt(delCost);
     dCost=dCost+d;
    pay=oCost;
    }
     String a=(String.format("%d",oCount));
     String b=(String.format("%d",oCost));
     String c=(String.format("%d",dCount));
     String d=(String.format("%d",dCost));
     
     
     }catch(SQLException e){}
    
    


        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.setValue(pay,"Transaction", "1");
        dataset.setValue(0, "Transaction", "2");
        dataset.setValue(0, "Transaction", "3");
        dataset.setValue(0, "Transaction", "4");
        dataset.setValue(13, "Transaction", "5");
        dataset.setValue(11, "Transaction", "6");
        dataset.setValue(11, "Transaction", "7");
        dataset.setValue(11, "Transaction", "8");
        dataset.setValue(11, "Transaction", "9");
        dataset.setValue(11, "Transaction", "10");
        dataset.setValue(11, "Transaction", "11");
        dataset.setValue(11, "Transaction", "12");
        dataset.setValue(11, "Gold medals", "13");
        dataset.setValue(11, "Gold medals", "14");
        dataset.setValue(11, "Gold medals", "15");
        dataset.setValue(11, "Gold medals", "16");
        dataset.setValue(11, "Gold medals", "17");
        dataset.setValue(11, "Gold medals", "18");
        dataset.setValue(11, "Gold medals", "19");
        dataset.setValue(11, "Gold medals", "20");
        dataset.setValue(11, "Gold medals", "21");
        dataset.setValue(11, "Gold medals", "22");
        dataset.setValue(11, "Gold medals", "23");
        dataset.setValue(11, "Gold medals", "24");
        dataset.setValue(11, "Gold medals", "25");
        dataset.setValue(11, "Gold medals", "26");
        dataset.setValue(11, "Gold medals", "27");
        dataset.setValue(11, "Gold medals", "28");
        dataset.setValue(11, "Gold medals", "29");
        dataset.setValue(11, "Gold medals", "30");
        dataset.setValue(11, "Gold medals", "31");

       
       
     return dataset;
    }

    private JFreeChart createChart(CategoryDataset dataset) {

        JFreeChart barChart = ChartFactory.createBarChart(
                "Daily Status",
                "Month",
                "Transactions",
                dataset,
                PlotOrientation.VERTICAL,
                false, true, false);

        return barChart;
    }
    
    ////////////////////////////////////////////////////////
    public void count(){
        AddStaffPayment fordate=new AddStaffPayment();
      String dte= fordate.setDate();
        DBconnection db=new DBconnection(); 
   
    try{
    String q="select * from OrdrDeliveryCount where count_date='"+dte+"' ";
            //+ "where ord_date='"+dateCount.getText()+"' ";
   
        PreparedStatement pst = db.conn.prepareStatement(q);
       
        ResultSet rs = pst.executeQuery();
       
      String ordCount="";
    String delCount="";
    String ordCost="";
    String delCost="";
    int oCount=0;
    int oCost=0;
    int dCount=0;
    int dCost=0;
    while(rs.next()){
     ordCount=rs.getString("no_of_order");
     int a=Integer.parseInt(ordCount);
     oCount=oCount+a;
     ordCost=rs.getString("cost_of_order");
     int b =Integer.parseInt(ordCost);
     oCost=oCost+b;
     
     delCount=rs.getString("no_of_delivery");
     int c=Integer.parseInt(delCount);
     dCount=dCount+c;
     delCost=rs.getString("cost_of_delivery");
     int d=Integer.parseInt(delCost);
     dCost=dCost+d;
    
    }
    String a=(String.format("%d",oCount));
     String b=(String.format("%d",oCost));
    String c=(String.format("%d",dCount));
    String d=(String.format("%d",dCost));
 
    
    
    }catch(SQLException e){}
    
    
    
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            BarChartEx ex = new BarChartEx();
            ex.setVisible(true);
        });
    }

}