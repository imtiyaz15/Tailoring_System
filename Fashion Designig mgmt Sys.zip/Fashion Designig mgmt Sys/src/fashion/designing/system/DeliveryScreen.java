/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fashion.designing.system;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ADMIN
 */
public class DeliveryScreen extends javax.swing.JFrame {
      public  String tot="";
       public String bal="";
       String name = "";
    /**
     * Creates new form DeliveryScreen
     */
    public DeliveryScreen() {
        initComponents();
        payButton.setVisible(false);
        
    }

////////////pay Balance Button//////////////////////
    public void payBalanceAmt(){
    try{
        AddStaffPayment forDate=new AddStaffPayment();
       String dte=forDate.setDate();
       AutoIncreament obj=new AutoIncreament();
       int idd=obj.auto_forTransactionID();
       System.out.println(idd);
       String transID=""+idd; 
        String me="Management";
        String dd="Delivered Dress";
        String s1=tot;
        String amt=bal;
        String s2="00";
     DBconnection DB=new DBconnection();
      Statement st = DB.conn.createStatement();
      int compare=Integer.parseInt(BAL.getText());
      int countDelivery=st.executeUpdate("insert into OrdrDeliveryCount(count_date,no_of_order,cost_of_order,no_of_delivery,cost_of_delivery)"
      +"values ( '"+dte+"',0,0,1,'"+tot+"')");
      
      if(countDelivery>0){
                 System.out.println("Save into Delivery count");
                 }
      
      if(compare>0){
          
     int a2=st.executeUpdate("insert into paymentHistory(tranID,amt,paid_to,paid_for,paid_date)"
                         + "values('"+transID+"','"+amt+"','"+me+"','"+dd+"','"+dte+"')");
     String sql = "Update payment SET paidamt= '"+s1+"',balamt = '"+s2+"' where ordno='"+txt.getText()+"'";
      
     int a=st.executeUpdate(sql);
     if(a2>0){
                 System.out.println("Save into transaction");
                 }
    if(a>0){
    JOptionPane.showMessageDialog(null,"Amount paid successfully \nThank you!");
    }
    
   }
      else{
          JOptionPane.showMessageDialog(null,"Thank you!\nAlready paid !");
      }
      
    }catch(SQLException e){
    JOptionPane.showMessageDialog(null,e);
    }
     
    }
    
    
////////////////////////////////getBalance
public void getBalance(){
       
DBconnection db=new DBconnection(); 
String q="select * from payment where ordno='"+txt.getText()+"'" ;
try{
            PreparedStatement pst = db.conn.prepareStatement(q);
           
            ResultSet rs = pst.executeQuery();
           
            String paid="";
           // String bal="";
            while(rs.next()){
                tot=rs.getString("totalamt");
                paid=rs.getString("paidamt");
                bal=rs.getString("balamt");
        
              } 
               l3.setText("Total   ₹: "+tot+".00");
               l2.setText("Paid    ₹:");
                       PAID.setText(""+paid);
              l1.setText("Balance  ₹:");
              BAL.setText(""+bal);
    }catch(SQLException e){}
    
}   
////////////////////////Show in table
public void showInfo2( JTable info){
    
          DBconnection db=new DBconnection(); 
   
       String q="select * from cust_info where ordno='"+txt.getText()+"'" ;
               //'"+txt.getText()+"' ";
    try{
            PreparedStatement pst = db.conn.prepareStatement(q);
         //   pst.setString(1,txt.getText());
            ResultSet rs = pst.executeQuery();
              DefaultTableModel model = new DefaultTableModel();
          String[] columnNames = {"ID", "Name", "Address", "Country","Contact"};
          model.setColumnIdentifiers(columnNames);
          info.setModel(model);
        String id = "";
        String name = "";
        String add = "";
        String cous = "";
         String contact = "";
   
         
            
           while(rs.next()) {
                id = rs.getString("ordno");
                name = rs.getString("cust_name");
                add = rs.getString("cust_add");
                cous = rs.getString("countryCode");
                contact = rs.getString("cust_contact");
                model.addRow(new Object[]{id,name, add, cous,contact});

            }
    }catch(SQLException e){}
    
    }
    /////////////////////////////////////Show on table
     public void showInfo( JTable info){
    
          DBconnection db=new DBconnection(); 
   
       String q="select * from cust_info where cust_name= ? "; //OR ordno='"+txt.getText()+"'" ;
               //'"+txt.getText()+"' ";
    try{
            PreparedStatement pst = db.conn.prepareStatement(q);
            pst.setString(1,txt.getText());
            ResultSet rs = pst.executeQuery();
              DefaultTableModel model = new DefaultTableModel();
          String[] columnNames = {"ID", "Name", "Address", "Country","Contact"};
          model.setColumnIdentifiers(columnNames);
          info.setModel(model);
        String id = "";
    ///    String name = ""; Declared globaly
        String add = "";
        String cous = "";
         String contact = "";
   
         
            
           while(rs.next()) {
                id = rs.getString("ordno");
                name = rs.getString("cust_name");
                add = rs.getString("cust_add");
                cous = rs.getString("countryCode");
                contact = rs.getString("cust_contact");
                model.addRow(new Object[]{id,name, add, cous,contact});

    }
    }catch(SQLException e){}
             

}
    
    
    
    
    
    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 32767));
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        deliveryTable = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        OkButton = new javax.swing.JButton();
        txt = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        l1 = new javax.swing.JLabel();
        l2 = new javax.swing.JLabel();
        l3 = new javax.swing.JLabel();
        BAL = new javax.swing.JLabel();
        PAID = new javax.swing.JLabel();
        payButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Delivery");

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));

        jScrollPane1.setBackground(new java.awt.Color(204, 204, 255));
        jScrollPane1.setOpaque(false);

        deliveryTable.setBackground(new java.awt.Color(204, 204, 255));
        deliveryTable.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        deliveryTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        deliveryTable.setGridColor(new java.awt.Color(255, 204, 255));
        deliveryTable.setOpaque(false);
        jScrollPane1.setViewportView(deliveryTable);

        jPanel2.setBackground(new java.awt.Color(142, 69, 86));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Ord No.");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 10, -1, -1));

        OkButton.setBackground(new java.awt.Color(142, 69, 86));
        OkButton.setForeground(new java.awt.Color(255, 255, 255));
        OkButton.setText("OK");
        OkButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OkButtonActionPerformed(evt);
            }
        });
        jPanel2.add(OkButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 60, -1, -1));

        txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtActionPerformed(evt);
            }
        });
        txt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtKeyReleased(evt);
            }
        });
        jPanel2.add(txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 30, 210, -1));

        jPanel3.setBackground(new java.awt.Color(255, 87, 0));

        jPanel4.setBackground(new java.awt.Color(255, 255, 153));

        l1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        l1.setForeground(new java.awt.Color(207, 20, 45));
        l1.setText("Balance ₹");

        l2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        l2.setForeground(new java.awt.Color(0, 100, 194));
        l2.setText("Paid      ₹");

        l3.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        l3.setForeground(new java.awt.Color(102, 102, 0));
        l3.setText("Total    ₹");

        BAL.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        BAL.setForeground(new java.awt.Color(207, 20, 45));

        PAID.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        PAID.setForeground(new java.awt.Color(0, 100, 194));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(l3, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(l1, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                            .addComponent(l2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(PAID, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
                            .addComponent(BAL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(l1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BAL, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(l2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PAID, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(l3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        payButton.setText("Pay");
        payButton.setToolTipText("Pay Balance Amount");
        payButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                payButtonActionPerformed(evt);
            }
        });

        jLabel2.setBackground(new java.awt.Color(255, 102, 51));
        jLabel2.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel2.setText("Delivery");
        jLabel2.setOpaque(true);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(76, 76, 76)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(102, 102, 102))
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 677, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 397, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(168, 168, 168)
                        .addComponent(payButton)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 55, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(payButton)
                .addGap(17, 17, 17))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void OkButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OkButtonActionPerformed
            if(txt.getText().length()==0){
                txt.setText("Enter order no. or name");
                txt.requestFocusInWindow();
                txt.selectAll();
                     
            }
           showInfo2(deliveryTable);  
           getBalance();
           
           String a=BAL.getText();
           int b=Integer.parseInt(a);
            System.out.println(b);
             if(b>0){
                    payButton.setVisible(true);
            }
        
    }//GEN-LAST:event_OkButtonActionPerformed

    private void txtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtKeyReleased
          showInfo(deliveryTable);
    }//GEN-LAST:event_txtKeyReleased

    private void txtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtActionPerformed
        getBalance();
        showInfo2(deliveryTable);
         
    }//GEN-LAST:event_txtActionPerformed

    private void payButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_payButtonActionPerformed

        payBalanceAmt();   
         showInfo2(deliveryTable);  
           getBalance();// TODO add your handling code here:
           
           payButton.setVisible(false);
    }//GEN-LAST:event_payButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DeliveryScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DeliveryScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DeliveryScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DeliveryScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DeliveryScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BAL;
    private javax.swing.JButton OkButton;
    private javax.swing.JLabel PAID;
    private javax.swing.JTable deliveryTable;
    private javax.swing.Box.Filler filler1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel l1;
    private javax.swing.JLabel l2;
    private javax.swing.JLabel l3;
    private javax.swing.JButton payButton;
    private javax.swing.JTextField txt;
    // End of variables declaration//GEN-END:variables
}
